package com.example.arduino_bluetooth

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.dreamcastbluethoot.R
import java.io.IOException
import java.io.InputStream
import java.util.*

class Connection : AppCompatActivity() {



    companion object {
        private const val TAG = "Connection"
        private const val BLUETOOTH_PERMISSION_REQUEST_CODE = 100
        private val MY_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        const val EXTRA_ADDRESS = "device_address"


    }

    private var address: String? = null
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var btSocket: BluetoothSocket? = null
    private var isBtConnected = false

    private lateinit var startConnectionButton: Button
    private lateinit var sendSampleButton: Button
    private lateinit var receiveButton: Button
    private lateinit var incomingDataTextView: TextView
    private lateinit var deviceNameTV: TextView
    private lateinit var disconnectButton: Button


    private var inputStream: InputStream? = null
    private val messages = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connection)

        address = intent.getStringExtra(EXTRA_ADDRESS)

        startConnectionButton = findViewById(R.id.btnStartConnection)
        deviceNameTV = findViewById(R.id.deviceNameTV)
        incomingDataTextView = findViewById(R.id.logsReceive)
        sendSampleButton = findViewById(R.id.btnSendSample)
        receiveButton = findViewById(R.id.btnReceive)
        disconnectButton = findViewById(R.id.btnDisconnect)

        startConnectionButton.visibility = Button.VISIBLE
        sendSampleButton.visibility = Button.INVISIBLE
        receiveButton.visibility = Button.INVISIBLE

        // Set click listeners
        startConnectionButton.setOnClickListener { ConnectBT().execute()
            sendSampleButton.visibility = Button.VISIBLE
        }
        disconnectButton.setOnClickListener { disconnect() }
        receiveButton.setOnClickListener { startReceivingData() }
        sendSampleButton.setOnClickListener { sendSampleData() }
    }



    private fun disconnect() {
        try {
            btSocket?.close()
            finish()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun startReceivingData() {
        val handler = Handler()
        val runnable = object : Runnable {
            override fun run() {
                listenForInput()
                incomingDataTextView.text = messages.toString()
                handler.postDelayed(this, 200)
            }
        }
        handler.post(runnable)
    }

    private fun sendSampleData() {
        if (btSocket != null && isBtConnected) {
            try {
                val outputStream = btSocket!!.outputStream
                val sampleData = "1"
                outputStream.write(sampleData.toByteArray())
                Log.d(TAG, "Sent sample data: $sampleData")
                Toast.makeText(this, "Sample Data Sent", Toast.LENGTH_SHORT).show()
                incomingDataTextView.setText("SampleData: $sampleData Logs Receive: /// ")
            } catch (e: IOException) {
                Log.e(TAG, "Error sending sample data", e)
            }
        } else {
            Toast.makeText(this, "Not connected to a device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun listenForInput() {
        inputStream = btSocket?.inputStream
        val buffer = ByteArray(1024)

        try {
            val bytes = inputStream?.read(buffer) ?: return
            val incomingMessage = String(buffer, 0, bytes)
            messages.append(incomingMessage)
            Log.d(TAG, "Received data: $incomingMessage")
            Toast.makeText(this, incomingMessage, Toast.LENGTH_SHORT).show()
            incomingDataTextView.setText(" , Received data: ${incomingMessage}")

        } catch (e: IOException) {
            Log.e(TAG, "Error reading input stream", e)
        }
    }

    private inner class ConnectBT : AsyncTask<Void, Void, Boolean>() {

        override fun onPreExecute() {
            Toast.makeText(this@Connection, "Connecting...", Toast.LENGTH_SHORT).show()
        }

        override fun doInBackground(vararg params: Void?): Boolean {
            return try {
                if (btSocket == null || !isBtConnected) {
                    if (ActivityCompat.checkSelfPermission(
                            this@Connection,
                            Manifest.permission.BLUETOOTH_CONNECT
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        ActivityCompat.requestPermissions(
                            this@Connection,
                            arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                            BLUETOOTH_PERMISSION_REQUEST_CODE
                        )
                        return false
                    }

                    bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                    val device = bluetoothAdapter?.getRemoteDevice(address)
                    btSocket = device?.createInsecureRfcommSocketToServiceRecord(MY_UUID)

                    if (ActivityCompat.checkSelfPermission(
                            this@Connection,
                            Manifest.permission.BLUETOOTH_SCAN
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        ActivityCompat.requestPermissions(
                            this@Connection,
                            arrayOf(Manifest.permission.BLUETOOTH_SCAN),
                            BLUETOOTH_PERMISSION_REQUEST_CODE
                        )
                        return false
                    }

                    bluetoothAdapter?.cancelDiscovery()
                    btSocket?.connect()
                }
                true
            } catch (e: IOException) {
                Log.e(TAG, "Connection failed", e)
                false
            }
        }

        override fun onPostExecute(success: Boolean) {
            if (success) {
                Toast.makeText(this@Connection, "Connection Successful", Toast.LENGTH_SHORT).show()
                isBtConnected = true
            } else {
                Toast.makeText(this@Connection, "Connection Failed", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

}
